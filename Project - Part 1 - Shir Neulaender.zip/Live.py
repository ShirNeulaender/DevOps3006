def welcome(name=input("please enter your name: ")):
    # name = input("please enter your name: ")
    print("Hello " + name + " and welcome to the World of Games (WoG).\nHere you can find many cool games to play.")
    return name


welcome()


def load_game():
    games = input("Please choose a game to play:\n 1. Memory Game - a sequence of numbers will appear for 1 second "
                  "and you have to guess it back \n 2. Guess Game - guess a number and see if you chose like the "
                  "computer\n 3. Currency Roulette - try and guess the value of a random amount of USD in ILS: \n ")

    while not ("1" <= games <= "3"):
        try:
            games = input("Please choose the game to play, 1,2,3 ")
            raise ValueError
        except ValueError:
            print("Oops!  That was no valid number.  Try again...")

    difficulty = input("Please choose a level of difficulty from 1 to 5: ")

    while not ("1" <= difficulty <= "5"):
        try:
            difficulty = input("Please choose a level of difficulty from 1 to 5: ")
            raise ValueError
        except ValueError:
            print("Oops!  That was no valid number.  Try again...")


load_game()
